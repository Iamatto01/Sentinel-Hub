import React, { useEffect, useState } from 'react'
import { X, Loader2, ShieldAlert, BookOpen, StickyNote, Send, ExternalLink } from 'lucide-react'
import { api } from '../lib/api.js'
import SeverityBadge from './SeverityBadge.jsx'

function safeParse(j, fallback) {
  if (!j) return fallback
  if (typeof j === 'object') return j
  try { return JSON.parse(j) } catch { return fallback }
}

export default function FindingDetailDrawer({ finding, onClose, onStatusChange }) {
  const [tab, setTab] = useState('overview')
  const [notes, setNotes] = useState([])
  const [noteText, setNoteText] = useState('')
  const [cve, setCve] = useState(null)
  const [cveBusy, setCveBusy] = useState(false)
  const [status, setStatus] = useState(finding?.status || 'open')

  useEffect(() => {
    if (!finding) return
    setStatus(finding.status || 'open')
    setTab('overview')
    setCve(null)
    api.findingNotes(finding.id).then(setNotes).catch(() => setNotes([]))
  }, [finding])

  if (!finding) return null

  const evidence = safeParse(finding.evidence, {})
  const poc = safeParse(finding.poc, {})
  const verdict = safeParse(finding.agent_verdict, null)
  const cveId = finding.cve_id || (finding.title.match(/CVE-\d{4}-\d{4,}/i)?.[0])

  async function loadCve() {
    if (!cveId) return
    setCveBusy(true)
    try { setCve(await api.cve(cveId)) } catch (e) { setCve({ error: e.message }) }
    setCveBusy(false)
  }

  async function saveStatus(s) {
    setStatus(s)
    try { await api.setFindingStatus(finding.id, s); onStatusChange?.(finding.id, s) } catch { /* noop */ }
  }

  async function addNote(e) {
    e.preventDefault()
    if (!noteText.trim()) return
    const n = await api.addFindingNote(finding.id, noteText.trim())
    setNotes((p) => [...p, n])
    setNoteText('')
  }

  const TABS = [
    { id: 'overview', label: 'Overview', icon: ShieldAlert },
    { id: 'poc', label: 'PoC / Evidence', icon: BookOpen },
    { id: 'cve', label: 'CVE', icon: ExternalLink },
    { id: 'notes', label: `Notes (${notes.length})`, icon: StickyNote },
  ]

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-xl h-full bg-ink-900 border-l border-ink-700 overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 z-10 bg-ink-900/95 backdrop-blur border-b border-ink-700 p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <h2 className="text-lg font-bold text-slate-100 leading-snug">{finding.title}</h2>
              <p className="text-xs text-slate-500 mt-1">{finding.target || finding.module}</p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <SeverityBadge severity={finding.severity} />
              <button onClick={onClose} className="text-slate-500 hover:text-slate-200"><X size={20} /></button>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <label className="text-[11px] uppercase tracking-wider text-slate-500">Status</label>
            <select value={status} onChange={(e) => saveStatus(e.target.value)} className="input py-1 px-2 text-xs w-auto">
              {['open', 'confirmed', 'in-progress', 'fixed', 'accepted', 'false-positive'].map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="mt-4 flex gap-1 border-b border-ink-700 -mb-5">
            {TABS.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setTab(id)}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-colors ${tab === id ? 'border-accent text-accent' : 'border-transparent text-slate-500 hover:text-slate-300'}`}>
                <Icon size={13} /> {label}
              </button>
            ))}
          </div>
        </div>

        <div className="p-5 space-y-4">
          {tab === 'overview' && (
            <>
              <div className="flex flex-wrap gap-2 text-[11px]">
                {finding.owasp_category && <span className="chip bg-accent/10 text-accent border border-accent/30">{finding.owasp_category}</span>}
                {finding.cwe_id && <span className="chip bg-ink-700 text-slate-300 border border-ink-600">{finding.cwe_id}</span>}
                {cveId && <span className="chip bg-sev-high/10 text-sev-high border border-sev-high/30">{cveId}</span>}
                {finding.cvss != null && <span className="chip bg-ink-700 text-slate-300 border border-ink-600">CVSS {finding.cvss}</span>}
              </div>
              {finding.description && (
                <div><p className="label">Description</p><p className="text-sm text-slate-300 whitespace-pre-wrap">{finding.description}</p></div>
              )}
              {verdict && (
                <div className="rounded-lg bg-accent/5 border border-accent/20 p-3">
                  <p className="text-[11px] uppercase tracking-wider text-accent/80 mb-1">Agent Verdict · {verdict.agent} · {Math.round((verdict.confidence || 0) * 100)}%</p>
                  <p className="text-xs text-slate-300 whitespace-pre-wrap">{verdict.reasoning}</p>
                </div>
              )}
              {finding.remediation && (
                <div className="rounded-lg bg-emerald-500/5 border border-emerald-500/20 p-3">
                  <p className="text-[11px] uppercase tracking-wider text-emerald-400/80 mb-1">Remediation</p>
                  <p className="text-sm text-emerald-100/90 whitespace-pre-wrap">{finding.remediation}</p>
                </div>
              )}
            </>
          )}

          {tab === 'poc' && (
            <>
              {Object.keys(evidence).length === 0 && Object.keys(poc).length === 0 && (
                <p className="text-sm text-slate-500">No evidence or PoC captured for this finding.</p>
              )}
              {Object.keys(evidence).length > 0 && (
                <div><p className="label">Evidence</p>
                  <pre className="terminal text-xs whitespace-pre-wrap">{JSON.stringify(evidence, null, 2)}</pre></div>
              )}
              {Object.keys(poc).length > 0 && (
                <div><p className="label">PoC / Payloads</p>
                  <pre className="terminal text-xs whitespace-pre-wrap">{JSON.stringify(poc, null, 2)}</pre></div>
              )}
            </>
          )}

          {tab === 'cve' && (
            <>
              {!cveId ? <p className="text-sm text-slate-500">No CVE associated with this finding.</p> : (
                <>
                  <button onClick={loadCve} disabled={cveBusy} className="btn-ghost">
                    {cveBusy ? <Loader2 size={15} className="animate-spin" /> : <ExternalLink size={15} />} Lookup {cveId} (NVD)
                  </button>
                  {cve && (
                    cve.error ? <p className="text-sm text-sev-critical">{cve.error}</p> : (
                      <div className="space-y-3">
                        <div className="flex items-center gap-3">
                          <h3 className="text-base font-bold text-slate-100">{cve.id}</h3>
                          {cve.cvss?.score != null && <SeverityBadge severity={(cve.severity || '').toLowerCase()} />}
                          {cve.cvss?.score != null && <span className="text-sm text-slate-300">{cve.cvss.score}/10</span>}
                          {cve.cached && <span className="text-[10px] text-slate-600">(cached)</span>}
                        </div>
                        <p className="text-sm text-slate-300 whitespace-pre-wrap">{cve.description}</p>
                        {cve.cvss?.vector && <p className="text-xs font-mono text-slate-500">{cve.cvss.vector}</p>}
                        {cve.weaknesses?.length > 0 && <div className="flex flex-wrap gap-1.5">{cve.weaknesses.map((w) => <span key={w} className="chip bg-ink-700 text-slate-300 border border-ink-600 text-[11px]">{w}</span>)}</div>}
                        {cve.references?.length > 0 && (
                          <div><p className="label">References</p>
                            <ul className="space-y-1">{cve.references.map((r) => <li key={r}><a href={r} target="_blank" rel="noreferrer" className="text-xs text-accent hover:underline break-all">{r}</a></li>)}</ul></div>
                        )}
                      </div>
                    )
                  )}
                </>
              )}
            </>
          )}

          {tab === 'notes' && (
            <>
              <div className="space-y-3">
                {notes.length === 0 && <p className="text-sm text-slate-500">No notes yet.</p>}
                {notes.map((n) => (
                  <div key={n.id} className="rounded-lg bg-ink-800/60 border border-ink-700/60 p-3">
                    <p className="text-[11px] text-slate-500 mb-1">{n.author} · {new Date(n.ts).toLocaleString()}</p>
                    <p className="text-sm text-slate-200 whitespace-pre-wrap">{n.note}</p>
                  </div>
                ))}
              </div>
              <form onSubmit={addNote} className="flex gap-2">
                <input className="input flex-1" placeholder="Add a note…" value={noteText} onChange={(e) => setNoteText(e.target.value)} />
                <button type="submit" className="btn-primary px-3"><Send size={15} /></button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

import React, { useEffect, useRef, useState } from 'react'
import { Bot, X, Send, Loader2, Sparkles } from 'lucide-react'
import { api } from '../lib/api.js'

export default function AIChatWidget() {
  const [open, setOpen] = useState(false)
  const [agents, setAgents] = useState([])
  const [agent, setAgent] = useState('web-hunter')
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hi — I can explain findings, suggest next steps, or help plan an attack path. Pick a specialist and ask.' },
  ])
  const endRef = useRef(null)

  useEffect(() => { api.agents().then((a) => setAgents(a || [])).catch(() => {}) }, [])
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages, open])

  async function send(e) {
    e.preventDefault()
    const text = input.trim()
    if (!text || busy) return
    const next = [...messages, { role: 'user', content: text }]
    setMessages(next)
    setInput('')
    setBusy(true)
    try {
      const history = next.slice(-8).map((m) => ({ role: m.role, content: m.content }))
      const res = await api.agentChat(text, agent, history)
      setMessages((p) => [...p, { role: 'assistant', content: res.reply || '(no reply)' }])
    } catch (err) {
      setMessages((p) => [...p, { role: 'assistant', content: `Error: ${err.message}` }])
    }
    setBusy(false)
  }

  return (
    <>
      {!open && (
        <button onClick={() => setOpen(true)} title="AI assistant"
          className="fixed bottom-6 right-6 z-50 h-13 w-13 rounded-full bg-accent text-ink-950 shadow-glow grid place-items-center hover:scale-105 transition-transform p-3.5">
          <Sparkles size={22} />
        </button>
      )}
      {open && (
        <div className="fixed bottom-6 right-6 z-50 w-full max-w-sm h-[540px] card flex flex-col overflow-hidden shadow-2xl">
          <div className="flex items-center justify-between px-4 py-3 border-b border-ink-700">
            <div className="flex items-center gap-2">
              <Bot size={18} className="text-accent" />
              <p className="text-sm font-semibold text-slate-100">AI Assistant</p>
            </div>
            <div className="flex items-center gap-2">
              <select value={agent} onChange={(e) => setAgent(e.target.value)} className="input py-1 px-2 text-xs w-auto max-w-[140px]">
                <option value="web-hunter">web-hunter</option>
                {agents.filter((a) => a.id !== 'web-hunter').slice(0, 30).map((a) => <option key={a.id} value={a.id}>{a.id}</option>)}
              </select>
              <button onClick={() => setOpen(false)} className="text-slate-500 hover:text-slate-200"><X size={18} /></button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] rounded-lg px-3 py-2 text-sm whitespace-pre-wrap ${m.role === 'user' ? 'bg-accent text-ink-950' : 'bg-ink-800 text-slate-200 border border-ink-700'}`}>
                  {m.content}
                </div>
              </div>
            ))}
            {busy && <div className="flex justify-start"><div className="bg-ink-800 border border-ink-700 rounded-lg px-3 py-2"><Loader2 size={15} className="animate-spin text-accent" /></div></div>}
            <div ref={endRef} />
          </div>
          <form onSubmit={send} className="p-3 border-t border-ink-700 flex gap-2">
            <input className="input flex-1" placeholder="Ask the specialist…" value={input} onChange={(e) => setInput(e.target.value)} />
            <button type="submit" disabled={busy} className="btn-primary px-3"><Send size={16} /></button>
          </form>
        </div>
      )}
    </>
  )
}

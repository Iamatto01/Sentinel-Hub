import React, { useState } from 'react'
import { X, Globe, FileCode2, Loader2 } from 'lucide-react'
import { api } from '../lib/api.js'

const BLACKBOX_MODULES = ['nmap', 'httpx', 'subfinder', 'katana', 'ffuf', 'nikto', 'nuclei', 'sqlmap', 'dalfox', 'arjun', 'wpscan']

export default function NewScanModal({ onClose, onStarted }) {
  const [mode, setMode] = useState('blackbox')
  const [target, setTarget] = useState('')
  const [objective, setObjective] = useState('comprehensive')
  const [modules, setModules] = useState(['nmap', 'httpx', 'nuclei'])
  const [verify, setVerify] = useState(true)
  const [code, setCode] = useState('')
  const [filename, setFilename] = useState('app.js')
  const [language, setLanguage] = useState('javascript')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')

  const toggle = (m) => setModules((p) => (p.includes(m) ? p.filter((x) => x !== m) : [...p, m]))

  async function submit(e) {
    e.preventDefault()
    setErr('')
    setBusy(true)
    try {
      let body
      if (mode === 'blackbox') {
        if (!target.trim()) throw new Error('Enter a target URL or host')
        body = { mode, target: target.trim(), objective, modules, verify }
      } else {
        if (!code.trim()) throw new Error('Paste source code to audit')
        body = { mode, files: [{ path: filename || 'snippet.txt', content: code }], language, focus: 'security', verify }
      }
      const res = await api.startScan(body)
      onStarted(res.scan.id)
    } catch (e2) {
      setErr(e2.message)
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="card w-full max-w-2xl max-h-[90vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-ink-700/60 px-6 py-4">
          <h2 className="text-lg font-semibold text-slate-100">New Assessment</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-200"><X size={20} /></button>
        </div>

        <form onSubmit={submit} className="p-6 space-y-5">
          <div className="grid grid-cols-2 gap-3">
            <button type="button" onClick={() => setMode('blackbox')}
              className={`card p-4 text-left transition-all ${mode === 'blackbox' ? 'border-accent/60 shadow-glow' : 'hover:border-ink-500'}`}>
              <Globe className={mode === 'blackbox' ? 'text-accent' : 'text-slate-500'} size={22} />
              <p className="mt-2 font-semibold text-slate-100">Blackbox</p>
              <p className="text-xs text-slate-500">External target via Hexstrike engine</p>
            </button>
            <button type="button" onClick={() => setMode('whitebox')}
              className={`card p-4 text-left transition-all ${mode === 'whitebox' ? 'border-accent/60 shadow-glow' : 'hover:border-ink-500'}`}>
              <FileCode2 className={mode === 'whitebox' ? 'text-accent' : 'text-slate-500'} size={22} />
              <p className="mt-2 font-semibold text-slate-100">Whitebox</p>
              <p className="text-xs text-slate-500">Source code audit via code-auditor agent</p>
            </button>
          </div>

          {mode === 'blackbox' ? (
            <>
              <div>
                <label className="label">Target</label>
                <input className="input" placeholder="https://example.com or 192.168.1.10" value={target} onChange={(e) => setTarget(e.target.value)} />
              </div>
              <div>
                <label className="label">Objective</label>
                <select className="input" value={objective} onChange={(e) => setObjective(e.target.value)}>
                  <option value="quick">Quick recon</option>
                  <option value="comprehensive">Comprehensive</option>
                  <option value="stealth">Stealth / low-and-slow</option>
                  <option value="web">Web application focus</option>
                </select>
              </div>
              <div>
                <label className="label">Modules ({modules.length})</label>
                <div className="flex flex-wrap gap-2">
                  {BLACKBOX_MODULES.map((m) => (
                    <button type="button" key={m} onClick={() => toggle(m)}
                      className={`chip border transition-colors ${modules.includes(m) ? 'bg-accent/15 text-accent border-accent/50' : 'bg-ink-800 text-slate-500 border-ink-600 hover:text-slate-300'}`}>
                      {m}
                    </button>
                  ))}
                </div>
                <p className="mt-2 text-[11px] text-slate-500">Leave a few selected, or none to let the engine auto-orchestrate a smart scan.</p>
              </div>
            </>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Filename</label>
                  <input className="input" value={filename} onChange={(e) => setFilename(e.target.value)} />
                </div>
                <div>
                  <label className="label">Language</label>
                  <select className="input" value={language} onChange={(e) => setLanguage(e.target.value)}>
                    {['javascript', 'typescript', 'python', 'php', 'java', 'go', 'ruby', 'csharp'].map((l) => <option key={l}>{l}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="label">Source code</label>
                <textarea className="input font-mono text-xs h-44 resize-y" placeholder="Paste source code here…" value={code} onChange={(e) => setCode(e.target.value)} />
              </div>
            </>
          )}

          <label className="flex items-center gap-2.5 text-sm text-slate-300 cursor-pointer">
            <input type="checkbox" checked={verify} onChange={(e) => setVerify(e.target.checked)}
              className="h-4 w-4 rounded border-ink-600 bg-ink-800 text-accent focus:ring-accent/40" />
            AI agent verification (reduce false positives)
          </label>

          {err && <div className="rounded-lg bg-sev-critical/10 border border-sev-critical/40 px-4 py-2.5 text-sm text-sev-critical">{err}</div>}

          <div className="flex justify-end gap-3 pt-1">
            <button type="button" onClick={onClose} className="btn-ghost">Cancel</button>
            <button type="submit" disabled={busy} className="btn-primary">
              {busy ? <Loader2 size={16} className="animate-spin" /> : null}
              {busy ? 'Launching…' : `Launch ${mode === 'blackbox' ? 'Scan' : 'Audit'}`}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

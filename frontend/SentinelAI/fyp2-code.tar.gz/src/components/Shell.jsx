import React, { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, Radar, Bug, FolderKanban, Plug, LogOut, Shield, Plus, Hexagon, Activity, Settings as SettingsIcon,
} from 'lucide-react'
import { useAuth } from '../lib/AuthContext.jsx'
import NewScanModal from './NewScanModal.jsx'
import AIChatWidget from './AIChatWidget.jsx'

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/scans', label: 'Scans', icon: Radar },
  { to: '/findings', label: 'Findings', icon: Bug },
  { to: '/projects', label: 'Projects', icon: FolderKanban },
  { to: '/monitoring', label: 'Monitoring', icon: Activity },
  { to: '/integrations', label: 'Integrations', icon: Plug },
  { to: '/settings', label: 'Settings', icon: SettingsIcon },
]

export default function Shell() {
  const { user, logout } = useAuth()
  const nav = useNavigate()
  const [showNew, setShowNew] = useState(false)

  return (
    <div className="min-h-screen bg-ink-950 grid-bg">
      <aside className="fixed inset-y-0 left-0 w-60 border-r border-ink-700/60 bg-ink-900/80 backdrop-blur flex flex-col z-40">
        <div className="flex items-center gap-2.5 px-5 h-16 border-b border-ink-700/60">
          <div className="relative">
            <Hexagon className="text-accent" size={26} strokeWidth={1.6} />
            <Shield className="absolute inset-0 m-auto text-accent" size={11} />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-100 leading-tight">FYP2</p>
            <p className="text-[10px] uppercase tracking-widest text-accent/70">Pentest Platform</p>
          </div>
        </div>

        <div className="p-3">
          <button onClick={() => setShowNew(true)} className="btn-primary w-full justify-center shadow-glow">
            <Plus size={16} /> New Scan
          </button>
        </div>

        <nav className="flex-1 px-3 space-y-1">
          {NAV.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive ? 'bg-ink-700/70 text-accent' : 'text-slate-400 hover:bg-ink-800 hover:text-slate-200'
                }`
              }
            >
              <Icon size={18} /> {label}
            </NavLink>
          ))}
        </nav>

        <div className="p-3 border-t border-ink-700/60">
          <div className="flex items-center justify-between rounded-lg bg-ink-800/60 px-3 py-2.5">
            <div className="min-w-0">
              <p className="text-sm font-medium text-slate-200 truncate">{user?.username}</p>
              <p className="text-[10px] uppercase tracking-wider text-accent/70">{user?.role}</p>
            </div>
            <button onClick={() => { logout(); nav('/login') }} title="Sign out"
              className="text-slate-500 hover:text-sev-critical transition-colors">
              <LogOut size={17} />
            </button>
          </div>
        </div>
      </aside>

      <main className="pl-60">
        <div className="mx-auto max-w-7xl px-6 py-6">
          <Outlet />
        </div>
      </main>

      {showNew && <NewScanModal onClose={() => setShowNew(false)} onStarted={(id) => { setShowNew(false); nav(`/scans/${id}`) }} />}
      <AIChatWidget />
    </div>
  )
}

import React from 'react'

export default function StatCard({ icon: Icon, label, value, sub, tone = 'accent' }) {
  const tones = {
    accent: 'text-accent', critical: 'text-sev-critical', high: 'text-sev-high',
    medium: 'text-sev-medium', low: 'text-sev-low', info: 'text-sev-info',
  }
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs uppercase tracking-wider text-slate-500">{label}</p>
          <p className="mt-2 text-3xl font-bold text-slate-100">{value}</p>
          {sub && <p className="mt-1 text-xs text-slate-500">{sub}</p>}
        </div>
        {Icon && (
          <div className={`rounded-lg bg-ink-800 p-2.5 ${tones[tone] || tones.accent}`}>
            <Icon size={20} />
          </div>
        )}
      </div>
    </div>
  )
}

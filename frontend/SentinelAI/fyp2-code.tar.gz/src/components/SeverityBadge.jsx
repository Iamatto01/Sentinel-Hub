import React from 'react'

const COLORS = {
  critical: 'bg-sev-critical/15 text-sev-critical border-sev-critical/40',
  high: 'bg-sev-high/15 text-sev-high border-sev-high/40',
  medium: 'bg-sev-medium/15 text-sev-medium border-sev-medium/40',
  low: 'bg-sev-low/15 text-sev-low border-sev-low/40',
  info: 'bg-sev-info/15 text-sev-info border-sev-info/40',
}

export default function SeverityBadge({ severity }) {
  const s = (severity || 'info').toLowerCase()
  return <span className={`chip border ${COLORS[s] || COLORS.info}`}>{s}</span>
}

import React, { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { Hexagon, Shield, Loader2 } from 'lucide-react'
import { useAuth } from '../lib/AuthContext.jsx'

export default function Login() {
  const { login } = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')

  async function submit(e) {
    e.preventDefault()
    setErr(''); setBusy(true)
    try {
      await login(username.trim(), password)
      nav(loc.state?.from?.pathname || '/dashboard', { replace: true })
    } catch (e2) {
      setErr(e2.message || 'Login failed')
      setBusy(false)
    }
  }

  return (
    <div className="min-h-screen grid place-items-center bg-ink-950 grid-bg p-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="relative mb-3">
            <Hexagon className="text-accent" size={56} strokeWidth={1.4} />
            <Shield className="absolute inset-0 m-auto text-accent" size={22} />
          </div>
          <h1 className="text-2xl font-bold text-slate-100">FYP2</h1>
          <p className="text-xs uppercase tracking-[0.2em] text-accent/70 mt-1">Unified Pentest Platform</p>
        </div>

        <form onSubmit={submit} className="card p-6 space-y-4">
          <div>
            <label className="label">Username</label>
            <input className="input" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" />
          </div>
          <div>
            <label className="label">Password</label>
            <input type="password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" placeholder="••••••••" />
          </div>
          {err && <div className="rounded-lg bg-sev-critical/10 border border-sev-critical/40 px-3 py-2 text-sm text-sev-critical">{err}</div>}
          <button type="submit" disabled={busy} className="btn-primary w-full justify-center">
            {busy && <Loader2 size={16} className="animate-spin" />}
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
          <p className="text-center text-[11px] text-slate-600">Default: admin / admin — change in production</p>
        </form>
      </div>
    </div>
  )
}

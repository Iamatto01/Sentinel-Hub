import React, { useEffect, useRef, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Loader2, Square, FileDown, ArrowLeft, Terminal, Bug, Pause, Play } from 'lucide-react'
import { api } from '../lib/api.js'
import { subscribeScan } from '../lib/socket.js'
import SeverityBadge from '../components/SeverityBadge.jsx'
import FindingDetailDrawer from '../components/FindingDetailDrawer.jsx'

export default function ScanDetail() {
  const { id } = useParams()
  const [scan, setScan] = useState(null)
  const [findings, setFindings] = useState([])
  const [logs, setLogs] = useState([])
  const [progress, setProgress] = useState(0)
  const [err, setErr] = useState('')
  const [reportBusy, setReportBusy] = useState(false)
  const [selected, setSelected] = useState(null)
  const termRef = useRef(null)

  useEffect(() => {
    api.scan(id)
      .then((d) => {
        setScan(d.scan)
        setFindings(d.findings || [])
        setLogs(d.logs || [])
        setProgress(d.scan.progress || 0)
      })
      .catch((e) => setErr(e.message))

    const unsub = subscribeScan(id, {
      onLog: (d) => setLogs((p) => [...p, { level: d.level, message: d.message, ts: d.ts }].slice(-500)),
      onFinding: (d) => setFindings((p) => [...p, d.finding]),
      onUpdate: (d) => setProgress(d.progress ?? 0),
      onDone: (d) => { setProgress(100); setScan((s) => (s ? { ...s, status: d.status || 'done', risk_score: d.riskScore } : s)) },
    })
    return unsub
  }, [id])

  useEffect(() => {
    if (termRef.current) termRef.current.scrollTop = termRef.current.scrollHeight
  }, [logs])

  async function stop() { await api.stopScan(id); setScan((s) => ({ ...s, status: 'stopped' })) }
  async function pause() { await api.pauseScan(id); setScan((s) => ({ ...s, status: 'paused' })) }
  async function resume() { await api.resumeScan(id); setScan((s) => ({ ...s, status: 'running' })) }
  async function genReport() {
    setReportBusy(true)
    try { await api.generateReport(id); window.open(`/api/reports/download/${id}`, '_blank') } catch (e) { setErr(e.message) }
    setReportBusy(false)
  }

  if (err) return <div className="card p-6 text-sev-critical">{err}</div>
  if (!scan) return <div className="flex justify-center py-20"><Loader2 className="animate-spin text-accent" size={28} /></div>

  const running = scan.status === 'running'
  const paused = scan.status === 'paused'
  const logColor = { info: 'text-slate-400', success: 'text-emerald-400', warn: 'text-sev-medium', error: 'text-sev-critical' }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/scans" className="text-slate-500 hover:text-slate-200"><ArrowLeft size={20} /></Link>
          <div>
            <h1 className="text-xl font-bold text-slate-100">{scan.target}</h1>
            <p className="text-sm text-slate-500">{scan.mode} • {scan.status}</p>
          </div>
        </div>
        <div className="flex gap-2">
          {running && <button onClick={pause} className="btn-ghost"><Pause size={15} /> Pause</button>}
          {paused && <button onClick={resume} className="btn-primary"><Play size={15} /> Resume</button>}
          {(running || paused) && <button onClick={stop} className="btn-danger"><Square size={15} /> Stop</button>}
          {!running && !paused && (
            <button onClick={genReport} disabled={reportBusy} className="btn-ghost">
              {reportBusy ? <Loader2 size={15} className="animate-spin" /> : <FileDown size={15} />} Report
            </button>
          )}
        </div>
      </div>

      <div className="card p-4">
        <div className="flex items-center justify-between mb-2 text-xs text-slate-500">
          <span>Progress</span>
          <span>{Math.round(progress)}% • Risk {(scan.risk_score ?? 0).toFixed(1)}/10</span>
        </div>
        <div className="h-2 rounded-full bg-ink-800 overflow-hidden">
          <div className="h-full bg-gradient-to-r from-accent-dim to-accent transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-5">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-200 mb-3">
            <Terminal size={16} className="text-accent" /> Live Output
            {running && <span className="chip bg-accent/15 text-accent border border-accent/40 ml-auto">streaming</span>}
          </h3>
          <div ref={termRef} className="terminal h-96">
            {logs.length === 0 && <p className="text-slate-600">Waiting for output…</p>}
            {logs.map((l, i) => (
              <div key={i} className="flex gap-2">
                <span className="text-slate-600 shrink-0">{new Date(l.ts).toLocaleTimeString()}</span>
                <span className={logColor[l.level] || 'text-slate-400'}>{l.message}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-200 mb-3">
            <Bug size={16} className="text-sev-high" /> Findings ({findings.length})
          </h3>
          <div className="space-y-2.5 max-h-96 overflow-auto pr-1">
            {findings.length === 0 && <p className="text-sm text-slate-600 py-10 text-center">No findings yet.</p>}
            {findings.map((f, i) => (
              <div key={f.id || i} onClick={() => setSelected(f)} className="rounded-lg bg-ink-800/60 border border-ink-700/60 p-3.5 cursor-pointer hover:border-ink-500 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <p className="text-sm font-medium text-slate-200 leading-snug">{f.title}</p>
                  <SeverityBadge severity={f.severity} />
                </div>
                {f.owasp_category && <p className="mt-1.5 text-[11px] text-accent/80">{f.owasp_category}</p>}
                {f.agent_verdict && <p className="mt-1 text-[11px] text-slate-500 italic line-clamp-2">{f.agent_verdict}</p>}
              </div>
            ))}
          </div>
        </div>
      </div>

      {selected && <FindingDetailDrawer finding={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}

import React, { useEffect, useMemo, useState } from 'react'
import { Loader2, Bug } from 'lucide-react'
import { api } from '../lib/api.js'
import SeverityBadge from '../components/SeverityBadge.jsx'
import FindingDetailDrawer from '../components/FindingDetailDrawer.jsx'

const SEVS = ['all', 'critical', 'high', 'medium', 'low', 'info']

export default function Findings() {
  const [findings, setFindings] = useState(null)
  const [filter, setFilter] = useState('all')
  const [err, setErr] = useState('')
  const [selected, setSelected] = useState(null)

  useEffect(() => { api.findings().then(setFindings).catch((e) => setErr(e.message)) }, [])

  function onStatusChange(id, status) {
    setFindings((p) => p.map((f) => (f.id === id ? { ...f, status } : f)))
    setSelected((s) => (s && s.id === id ? { ...s, status } : s))
  }

  const list = useMemo(
    () => (findings || []).filter((f) => filter === 'all' || f.severity === filter),
    [findings, filter]
  )

  if (err) return <div className="card p-6 text-sev-critical">{err}</div>
  if (!findings) return <div className="flex justify-center py-20"><Loader2 className="animate-spin text-accent" size={28} /></div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Findings</h1>
          <p className="text-sm text-slate-500">{findings.length} vulnerabilities across all scans</p>
        </div>
        <div className="flex gap-1.5">
          {SEVS.map((s) => (
            <button key={s} onClick={() => setFilter(s)}
              className={`chip border capitalize transition-colors ${filter === s ? 'bg-accent/15 text-accent border-accent/50' : 'bg-ink-800 text-slate-500 border-ink-600 hover:text-slate-300'}`}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <div className="card p-16 text-center">
          <Bug className="mx-auto text-slate-600 mb-3" size={40} />
          <p className="text-slate-400">No findings match this filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {list.map((f) => (
            <div key={f.id} onClick={() => setSelected(f)} className="card p-5 hover:border-ink-500 transition-colors cursor-pointer">
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-semibold text-slate-100 leading-snug">{f.title}</h3>
                <SeverityBadge severity={f.severity} />
              </div>
              <p className="mt-1 text-[11px] text-slate-500">{f.target}</p>
              {f.description && <p className="mt-2 text-sm text-slate-400 line-clamp-3">{f.description}</p>}
              <div className="mt-3 flex flex-wrap gap-2 text-[11px]">
                {f.owasp_category && <span className="chip bg-accent/10 text-accent border border-accent/30">{f.owasp_category}</span>}
                {f.cwe_id && <span className="chip bg-ink-700 text-slate-400 border border-ink-600">{f.cwe_id}</span>}
                {f.module && <span className="chip bg-ink-700 text-slate-400 border border-ink-600">{f.module}</span>}
              </div>
              {f.remediation && (
                <div className="mt-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20 px-3 py-2">
                  <p className="text-[11px] uppercase tracking-wider text-emerald-400/80 mb-1">Remediation</p>
                  <p className="text-xs text-emerald-200/80 line-clamp-2">{f.remediation}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {selected && <FindingDetailDrawer finding={selected} onClose={() => setSelected(null)} onStatusChange={onStatusChange} />}
    </div>
  )
}

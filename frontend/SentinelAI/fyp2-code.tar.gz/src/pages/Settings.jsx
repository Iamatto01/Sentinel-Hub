import React, { useEffect, useState } from 'react'
import { Loader2, Save, KeyRound, UserCircle, CheckCircle2 } from 'lucide-react'
import { api } from '../lib/api.js'
import { useAuth } from '../lib/AuthContext.jsx'

export default function Settings() {
  const { user, setUser } = useAuth()
  const [email, setEmail] = useState('')
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirm: '' })
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')
  const [status, setStatus] = useState(null)

  useEffect(() => {
    api.me().then((u) => setEmail(u.email || '')).catch(() => {})
    api.status().then(setStatus).catch(() => {})
  }, [])

  async function saveProfile(e) {
    e.preventDefault(); setMsg(''); setErr('')
    try { const u = await api.updateMe({ email }); setUser?.(u); setMsg('Profile saved.') }
    catch (e2) { setErr(e2.message) }
  }

  async function savePassword(e) {
    e.preventDefault(); setMsg(''); setErr('')
    if (pw.newPassword !== pw.confirm) { setErr('New passwords do not match'); return }
    try { await api.changePassword(pw.currentPassword, pw.newPassword); setMsg('Password changed.'); setPw({ currentPassword: '', newPassword: '', confirm: '' }) }
    catch (e2) { setErr(e2.message) }
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-100">Settings</h1>
        <p className="text-sm text-slate-500">Account & system</p>
      </div>

      {msg && <div className="card p-3 text-emerald-400 text-sm flex items-center gap-2"><CheckCircle2 size={16} /> {msg}</div>}
      {err && <div className="card p-3 text-sev-critical text-sm">{err}</div>}

      <form onSubmit={saveProfile} className="card p-5 space-y-4">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-200"><UserCircle size={16} className="text-accent" /> Profile</h3>
        <div><label className="label">Username</label><input className="input" value={user?.username || ''} disabled /></div>
        <div><label className="label">Role</label><input className="input" value={user?.role || ''} disabled /></div>
        <div><label className="label">Email</label><input className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div className="flex justify-end"><button type="submit" className="btn-primary"><Save size={15} /> Save</button></div>
      </form>

      <form onSubmit={savePassword} className="card p-5 space-y-4">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-200"><KeyRound size={16} className="text-accent" /> Change Password</h3>
        <div><label className="label">Current password</label><input type="password" className="input" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} required /></div>
        <div><label className="label">New password</label><input type="password" className="input" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} required /></div>
        <div><label className="label">Confirm new password</label><input type="password" className="input" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} required /></div>
        <div className="flex justify-end"><button type="submit" className="btn-primary"><Save size={15} /> Update Password</button></div>
      </form>

      {status && (
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-3">System Status</h3>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Engine</span><span className={status.engine?.available ? 'text-emerald-400' : 'text-sev-critical'}>{status.engine?.available ? 'online' : 'offline'}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Agents</span><span className="text-slate-200">{status.agents?.count ?? 0}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">RAG docs</span><span className="text-slate-200">{status.rag?.docs ?? 0}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">AI</span><span className={status.ai?.configured ? 'text-emerald-400' : 'text-slate-500'}>{status.ai?.configured ? 'configured' : 'not set'}</span></div>
          </div>
        </div>
      )}
    </div>
  )
}

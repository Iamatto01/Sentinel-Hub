import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Radar, Bug, FolderKanban, Activity, Loader2 } from 'lucide-react'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts'
import { api } from '../lib/api.js'
import StatCard from '../components/StatCard.jsx'
import SeverityBadge from '../components/SeverityBadge.jsx'

const SEV_COLORS = { critical: '#f43f5e', high: '#fb923c', medium: '#facc15', low: '#38bdf8', info: '#94a3b8' }

export default function Dashboard() {
  const [data, setData] = useState(null)
  const [err, setErr] = useState('')

  useEffect(() => {
    api.dashboard().then(setData).catch((e) => setErr(e.message))
  }, [])

  if (err) return <div className="card p-6 text-sev-critical">{err}</div>
  if (!data) return <div className="flex justify-center py-20"><Loader2 className="animate-spin text-accent" size={28} /></div>

  const sevData = Object.entries(data.severity || {})
    .filter(([, v]) => v > 0)
    .map(([name, value]) => ({ name, value }))

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Dashboard</h1>
          <p className="text-sm text-slate-500">Operational overview of assessments & findings</p>
        </div>
        {data.runningScans > 0 && (
          <span className="chip bg-accent/15 text-accent border border-accent/40 animate-pulse-slow">
            <Activity size={12} className="mr-1" /> {data.runningScans} running
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={FolderKanban} label="Projects" value={data.totals.projects} />
        <StatCard icon={Radar} label="Total Scans" value={data.totals.scans} tone="low" />
        <StatCard icon={Bug} label="Findings" value={data.totals.findings} tone="high" />
        <StatCard icon={Activity} label="Active Scans" value={data.runningScans} tone="accent" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-slate-200 mb-4">Severity Distribution</h3>
          {sevData.length ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={sevData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={80} paddingAngle={3}>
                  {sevData.map((e) => <Cell key={e.name} fill={SEV_COLORS[e.name]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: '#111a2e', border: '1px solid #24304a', borderRadius: 8, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-sm text-slate-500 py-16 text-center">No findings yet — launch a scan.</p>
          )}
          <div className="mt-2 grid grid-cols-5 gap-1">
            {Object.keys(SEV_COLORS).map((s) => (
              <div key={s} className="text-center">
                <div className="mx-auto h-1.5 w-6 rounded" style={{ background: SEV_COLORS[s] }} />
                <p className="mt-1 text-[10px] uppercase text-slate-500">{s.slice(0, 4)}</p>
                <p className="text-xs font-semibold text-slate-300">{data.severity?.[s] || 0}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-slate-200">Recent Scans</h3>
            <Link to="/scans" className="text-xs text-accent hover:underline">View all</Link>
          </div>
          <div className="space-y-2">
            {(data.recentScans || []).length === 0 && <p className="text-sm text-slate-500 py-10 text-center">No scans yet.</p>}
            {(data.recentScans || []).map((s) => (
              <Link key={s.id} to={`/scans/${s.id}`}
                className="flex items-center justify-between rounded-lg bg-ink-800/50 hover:bg-ink-800 px-4 py-3 transition-colors">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-200 truncate">{s.target}</p>
                  <p className="text-[11px] text-slate-500">{s.mode} • {new Date(s.created_at).toLocaleString()}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`chip border ${s.status === 'running' ? 'bg-accent/15 text-accent border-accent/40' : s.status === 'done' ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/40' : 'bg-ink-700 text-slate-400 border-ink-600'}`}>
                    {s.status}
                  </span>
                  <span className="text-sm font-semibold text-slate-300">{(s.risk_score ?? 0).toFixed(1)}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Loader2, Plus, Trash2, FolderKanban, X, Radar, Bug } from 'lucide-react'
import { api } from '../lib/api.js'
import SeverityBadge from '../components/SeverityBadge.jsx'

export default function Projects() {
  const [projects, setProjects] = useState(null)
  const [showNew, setShowNew] = useState(false)
  const [selected, setSelected] = useState(null)
  const [form, setForm] = useState({ name: '', client: '', description: '', scope: '' })
  const [err, setErr] = useState('')
  const nav = useNavigate()

  const load = () => api.projects().then(setProjects).catch((e) => setErr(e.message))
  useEffect(() => { load() }, [])

  async function create(e) {
    e.preventDefault()
    try { await api.createProject(form); setShowNew(false); setForm({ name: '', client: '', description: '', scope: '' }); load() }
    catch (e2) { setErr(e2.message) }
  }
  async function remove(id) { await api.deleteProject(id); if (selected?.id === id) setSelected(null); load() }

  if (!projects) return <div className="flex justify-center py-20"><Loader2 className="animate-spin text-accent" size={28} /></div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Projects</h1>
          <p className="text-sm text-slate-500">Client engagements & scope</p>
        </div>
        <button onClick={() => setShowNew(true)} className="btn-primary"><Plus size={16} /> New Project</button>
      </div>

      {err && <div className="card p-4 text-sev-critical text-sm">{err}</div>}

      {projects.length === 0 ? (
        <div className="card p-16 text-center">
          <FolderKanban className="mx-auto text-slate-600 mb-3" size={40} />
          <p className="text-slate-400">No projects yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((p) => (
            <div key={p.id} onClick={() => setSelected(p)} className="card p-5 cursor-pointer hover:border-ink-500 transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold text-slate-100">{p.name}</h3>
                  {p.client && <p className="text-xs text-accent/80 mt-0.5">{p.client}</p>}
                </div>
                <button onClick={(e) => { e.stopPropagation(); remove(p.id) }} className="text-slate-600 hover:text-sev-critical"><Trash2 size={16} /></button>
              </div>
              {p.description && <p className="mt-2 text-sm text-slate-400 line-clamp-2">{p.description}</p>}
              {p.scope && <p className="mt-2 text-xs text-slate-500 font-mono line-clamp-1">Scope: {p.scope}</p>}
              <p className="mt-3 text-[10px] uppercase tracking-wider text-slate-600">{p.status} • {p.risk_level}</p>
            </div>
          ))}
        </div>
      )}

      {selected && <ProjectDetail project={selected} onClose={() => setSelected(null)} onDelete={remove} nav={nav} />}

      {showNew && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-4" onClick={() => setShowNew(false)}>
          <form onSubmit={create} className="card w-full max-w-md p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-slate-100">New Project</h2>
              <button type="button" onClick={() => setShowNew(false)} className="text-slate-500 hover:text-slate-200"><X size={20} /></button>
            </div>
            <div><label className="label">Name *</label><input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
            <div><label className="label">Client</label><input className="input" value={form.client} onChange={(e) => setForm({ ...form, client: e.target.value })} /></div>
            <div><label className="label">Description</label><textarea className="input h-20" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
            <div><label className="label">Scope</label><input className="input font-mono text-xs" placeholder="*.example.com, 10.0.0.0/24" value={form.scope} onChange={(e) => setForm({ ...form, scope: e.target.value })} /></div>
            <div className="flex justify-end gap-3 pt-1">
              <button type="button" onClick={() => setShowNew(false)} className="btn-ghost">Cancel</button>
              <button type="submit" className="btn-primary">Create</button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}

function ProjectDetail({ project, onClose, onDelete, nav }) {
  const [scans, setScans] = useState(null)

  useEffect(() => {
    api.scans()
      .then((all) => setScans((all || []).filter((s) => s.project_id === project.id)))
      .catch(() => setScans([]))
  }, [project.id])

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="card w-full max-w-2xl p-6 space-y-5 max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-100">{project.name}</h2>
            {project.client && <p className="text-sm text-accent/80 mt-0.5">{project.client}</p>}
          </div>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-200"><X size={20} /></button>
        </div>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="rounded-lg bg-ink-800/60 border border-ink-700/60 p-3"><p className="label mb-1">Status</p><p className="text-slate-200 capitalize">{project.status}</p></div>
          <div className="rounded-lg bg-ink-800/60 border border-ink-700/60 p-3"><p className="label mb-1">Risk Level</p><p className="text-slate-200 capitalize">{project.risk_level}</p></div>
        </div>

        {project.description && <div><p className="label">Description</p><p className="text-sm text-slate-300 whitespace-pre-wrap">{project.description}</p></div>}
        {project.scope && <div><p className="label">Scope</p><p className="text-sm font-mono text-slate-300 whitespace-pre-wrap">{project.scope}</p></div>}

        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="label mb-0">Linked Scans</p>
            <button onClick={() => nav('/scans')} className="text-xs text-accent hover:underline flex items-center gap-1"><Radar size={13} /> View all</button>
          </div>
          {!scans ? <div className="flex justify-center py-6"><Loader2 className="animate-spin text-accent" size={20} /></div>
            : scans.length === 0 ? <p className="text-sm text-slate-600 py-4">No scans linked to this project yet.</p>
            : (
              <div className="space-y-2">
                {scans.slice(0, 10).map((s) => (
                  <button key={s.id} onClick={() => nav(`/scans/${s.id}`)} className="w-full text-left rounded-lg bg-ink-800/50 border border-ink-700/50 p-3 hover:border-ink-500 transition-colors">
                    <div className="flex items-center justify-between gap-3">
                      <p className="text-sm text-slate-200 truncate font-mono">{s.target}</p>
                      <span className="text-[11px] text-slate-500 shrink-0">{s.status}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-2"><Bug size={12} /> risk {(s.risk_score ?? 0).toFixed(1)} · {s.mode} · {new Date(s.created_at).toLocaleDateString()}</p>
                  </button>
                ))}
              </div>
            )}
        </div>

        <div className="flex justify-between pt-2 border-t border-ink-700">
          <button onClick={() => { onDelete(project.id) }} className="btn-danger"><Trash2 size={15} /> Delete Project</button>
          <button onClick={onClose} className="btn-ghost">Close</button>
        </div>
      </div>
    </div>
  )
}

import React, { useEffect, useState } from 'react'
import { Loader2, RefreshCw, Cpu, Database, Bot, Sparkles, CheckCircle2, XCircle } from 'lucide-react'
import { api } from '../lib/api.js'

function StatusDot({ ok }) {
  return ok
    ? <CheckCircle2 size={18} className="text-emerald-400" />
    : <XCircle size={18} className="text-sev-critical" />
}

export default function Integrations() {
  const [status, setStatus] = useState(null)
  const [agents, setAgents] = useState([])
  const [err, setErr] = useState('')
  const [reindexing, setReindexing] = useState(false)

  const load = () => {
    api.status().then(setStatus).catch((e) => setErr(e.message))
    api.agents().then(setAgents).catch(() => {})
  }
  useEffect(() => { load() }, [])

  async function reindex() {
    setReindexing(true)
    try { await api.reindexPayloads(); load() } catch (e) { setErr(e.message) }
    setReindexing(false)
  }

  if (!status) return <div className="flex justify-center py-20"><Loader2 className="animate-spin text-accent" size={28} /></div>

  const engine = status.engine || {}
  const rag = status.rag || {}

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-100">Integrations</h1>
        <p className="text-sm text-slate-500">Engine, knowledge base, agents & AI provider status</p>
      </div>

      {err && <div className="card p-4 text-sev-critical text-sm">{err}</div>}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Hexstrike engine */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="flex items-center gap-2 font-semibold text-slate-100"><Cpu size={18} className="text-accent" /> Hexstrike Engine</h3>
            <StatusDot ok={engine.ok} />
          </div>
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between"><dt className="text-slate-500">Status</dt><dd className={engine.ok ? 'text-emerald-400' : 'text-sev-critical'}>{engine.ok ? 'online' : 'offline'}</dd></div>
            {engine.version && <div className="flex justify-between"><dt className="text-slate-500">Version</dt><dd className="text-slate-300">{engine.version}</dd></div>}
            <div className="flex justify-between"><dt className="text-slate-500">Tools available</dt><dd className="text-slate-300">{engine.toolsAvailable ?? engine.total_tools_available ?? '—'}</dd></div>
          </dl>
          {!engine.ok && <p className="mt-3 text-xs text-sev-medium">Start the engine: <code className="text-accent">python hexstrike_server.py</code></p>}
        </div>

        {/* Payloads RAG */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="flex items-center gap-2 font-semibold text-slate-100"><Database size={18} className="text-accent" /> Payloads RAG</h3>
            <StatusDot ok={rag.installed && rag.docs > 0} />
          </div>
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between"><dt className="text-slate-500">Corpus installed</dt><dd className="text-slate-300">{rag.installed ? 'yes' : 'no'}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-500">Indexed docs</dt><dd className="text-slate-300">{rag.docs}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-500">Categories</dt><dd className="text-slate-300">{rag.categories?.length ?? 0}</dd></div>
          </dl>
          <button onClick={reindex} disabled={reindexing} className="btn-ghost mt-4 w-full justify-center">
            <RefreshCw size={15} className={reindexing ? 'animate-spin' : ''} /> {reindexing ? 'Reindexing…' : 'Rebuild index'}
          </button>
        </div>

        {/* Agents */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="flex items-center gap-2 font-semibold text-slate-100"><Bot size={18} className="text-accent" /> Specialist Agents</h3>
            <StatusDot ok={agents.length > 0} />
          </div>
          <p className="text-sm text-slate-400 mb-3">{agents.length} personas loaded</p>
          <div className="flex flex-wrap gap-1.5 max-h-40 overflow-auto">
            {agents.map((a) => (
              <span key={a.name} title={a.description} className="chip bg-ink-800 text-slate-400 border border-ink-600">{a.name}</span>
            ))}
          </div>
        </div>

        {/* AI provider */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="flex items-center gap-2 font-semibold text-slate-100"><Sparkles size={18} className="text-accent" /> AI Provider</h3>
            <StatusDot ok={status.ai?.configured} />
          </div>
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between"><dt className="text-slate-500">Provider</dt><dd className="text-slate-300">{status.ai?.provider}</dd></div>
            <div className="flex justify-between"><dt className="text-slate-500">Configured</dt><dd className={status.ai?.configured ? 'text-emerald-400' : 'text-sev-critical'}>{status.ai?.configured ? 'yes' : 'no'}</dd></div>
          </dl>
          {!status.ai?.configured && <p className="mt-3 text-xs text-sev-medium">Set API keys in <code className="text-accent">.env</code></p>}
        </div>
      </div>
    </div>
  )
}

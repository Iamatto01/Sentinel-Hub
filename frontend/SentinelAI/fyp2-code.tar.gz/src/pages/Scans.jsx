import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Loader2, Radar } from 'lucide-react'
import { api } from '../lib/api.js'

const STATUS_STYLE = {
  running: 'bg-accent/15 text-accent border-accent/40',
  done: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/40',
  failed: 'bg-sev-critical/15 text-sev-critical border-sev-critical/40',
  stopped: 'bg-ink-700 text-slate-400 border-ink-600',
}

export default function Scans() {
  const [scans, setScans] = useState(null)
  const [err, setErr] = useState('')

  useEffect(() => { api.scans().then(setScans).catch((e) => setErr(e.message)) }, [])

  if (err) return <div className="card p-6 text-sev-critical">{err}</div>
  if (!scans) return <div className="flex justify-center py-20"><Loader2 className="animate-spin text-accent" size={28} /></div>

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-100">Scans</h1>
        <p className="text-sm text-slate-500">All blackbox & whitebox assessments</p>
      </div>

      {scans.length === 0 ? (
        <div className="card p-16 text-center">
          <Radar className="mx-auto text-slate-600 mb-3" size={40} />
          <p className="text-slate-400">No scans yet. Click "New Scan" to begin.</p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-700/60 text-left text-xs uppercase tracking-wider text-slate-500">
                <th className="px-5 py-3">Target</th>
                <th className="px-5 py-3">Mode</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3">Findings</th>
                <th className="px-5 py-3">Risk</th>
                <th className="px-5 py-3">Started</th>
              </tr>
            </thead>
            <tbody>
              {scans.map((s) => (
                <tr key={s.id} className="border-b border-ink-800 hover:bg-ink-800/40 transition-colors">
                  <td className="px-5 py-3">
                    <Link to={`/scans/${s.id}`} className="text-slate-200 hover:text-accent font-medium">{s.target}</Link>
                  </td>
                  <td className="px-5 py-3 text-slate-400">{s.mode}</td>
                  <td className="px-5 py-3"><span className={`chip border ${STATUS_STYLE[s.status] || STATUS_STYLE.stopped}`}>{s.status}</span></td>
                  <td className="px-5 py-3 text-slate-300">{s.findings_count ?? '—'}</td>
                  <td className="px-5 py-3 font-semibold text-slate-200">{(s.risk_score ?? 0).toFixed(1)}</td>
                  <td className="px-5 py-3 text-slate-500 text-xs">{new Date(s.created_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

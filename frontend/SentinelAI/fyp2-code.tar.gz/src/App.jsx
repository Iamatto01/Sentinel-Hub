import React from 'react'
import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { useAuth } from './lib/AuthContext.jsx'
import Shell from './components/Shell.jsx'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Scans from './pages/Scans.jsx'
import ScanDetail from './pages/ScanDetail.jsx'
import Findings from './pages/Findings.jsx'
import Projects from './pages/Projects.jsx'
import Integrations from './pages/Integrations.jsx'
import Monitoring from './pages/Monitoring.jsx'
import Settings from './pages/Settings.jsx'
import AIChatWidget from './components/AIChatWidget.jsx'

function Protected({ children }) {
  const { isAuthed, loading } = useAuth()
  const loc = useLocation()
  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center bg-ink-950">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 rounded-full border-2 border-ink-600 border-t-accent animate-spin" />
          <p className="text-sm text-slate-400">Initializing…</p>
        </div>
      </div>
    )
  }
  if (!isAuthed) return <Navigate to="/login" state={{ from: loc }} replace />
  return children
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Protected><Shell /></Protected>}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="scans" element={<Scans />} />
        <Route path="scans/:id" element={<ScanDetail />} />
        <Route path="findings" element={<Findings />} />
        <Route path="projects" element={<Projects />} />
        <Route path="monitoring" element={<Monitoring />} />
        <Route path="integrations" element={<Integrations />} />
        <Route path="settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>
    </Routes>
  )
}
